from django.db import models

class Message(models.Model):
    title = models.CharField(max_length=30)
    content = models.CharField(max_length=100)
    url = models.CharField(max_length=100)

    def __unicode__(self):
        return self.title + "#" + self.content + "#" + self.url

