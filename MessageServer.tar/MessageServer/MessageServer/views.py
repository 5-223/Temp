from django.http import HttpResponse
import datetime

