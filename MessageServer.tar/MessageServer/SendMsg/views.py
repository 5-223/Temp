from django.shortcuts import render
import random
from models import Message

# Create your views here.
def get_message(request):
    msgList = Message.objects.all()
    index = random.randint(0, len(msgList) - 1)

    title = msgList[index].title
    content = msgList[index].content
    url = msgList[index].url

    return render(request, 'message.html', {'title':title, 'content':content, 'url':url})

